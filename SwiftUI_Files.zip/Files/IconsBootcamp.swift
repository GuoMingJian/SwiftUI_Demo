//
//  IconsBootcamp.swift
//  SwiftUI_Bootcamp
//
//  Created by GuoMingJian on 2024/3/9.
//

import SwiftUI

struct IconsBootcamp: View {
    var body: some View {
        Image(systemName: "person.3.sequence.fill")
            .renderingMode(.original)
            .font(.largeTitle)
        //            .resizable()
        //            .aspectRatio(contentMode: .fit)
        //            .scaledToFit()
        //            .scaledToFill()
        //            .font(.largeTitle)
        //            .font(.system(size: 100))
        //            .foregroundColor(
        //                Color(#colorLiteral(red: 1, green: 0.56, blue: 0, alpha: 1)))
            .foregroundColor(.red)
        //            .frame(width: 300, height: 300)
        //            .clipped()
    }
}

#Preview {
    IconsBootcamp()
}
