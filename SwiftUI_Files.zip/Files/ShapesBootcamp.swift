//
//  ShapesBootcamp.swift
//  SwiftUI_Bootcamp
//
//  Created by GuoMingJian on 2024/3/9.
//

import SwiftUI

struct ShapesBootcamp: View {
    var body: some View {
        //        Circle()
        //        Ellipse()
        //        Capsule(style: .circular)
        //        Rectangle()
        RoundedRectangle(cornerRadius: 50)
        //            .fill(Color.orange)
        //            .foregroundColor(.pink)
        //            .stroke()
        //            .stroke(Color.red)
        //            .stroke(Color.orange, lineWidth: 30)
        //            .stroke(Color.orange, style: StrokeStyle(lineWidth: 20, lineCap: .butt, dash: [10]))
        //            .trim(from: 0.25, to: 1)
        //            .stroke(Color.purple, lineWidth: 50)
            .frame(width: 300, height: 200)
    }
}

#Preview {
    ShapesBootcamp()
}
