//
//  ImageBootcamp.swift
//  SwiftUI_Bootcamp
//
//  Created by GuoMingJian on 2024/3/9.
//

import SwiftUI

struct ImageBootcamp: View {
    var body: some View {
        Image("bg1")
        //            .renderingMode(.template)
            .resizable()
        //            .aspectRatio(contentMode: .fill)
        //            .scaledToFit()
            .scaledToFill()
            .frame(width: 300, height: 200)
        //            .foregroundColor(.red)
        //            .clipped()
        //            .cornerRadius(30)
            .clipShape(
                //                Circle()
                //                RoundedRectangle(cornerRadius: 25)
                //                Ellipse()
                Circle()
            )
    }
}

#Preview {
    ImageBootcamp()
}
