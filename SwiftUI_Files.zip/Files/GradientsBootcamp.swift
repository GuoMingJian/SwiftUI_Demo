//
//  GradientsBootcamp.swift
//  SwiftUI_Bootcamp
//
//  Created by GuoMingJian on 2024/3/9.
//

import SwiftUI

struct GradientsBootcamp: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 25.0)
            .fill(
                //Color.red
                //                LinearGradient(
                //                    gradient: Gradient(colors: [Color.red, Color.blue]),
                //                    startPoint: .topLeading,
                //                    endPoint: .bottomTrailing)
                //                RadialGradient(gradient: Gradient(colors: [Color.red, Color.blue]), center: .topLeading, startRadius: 5, endRadius: 400)
                AngularGradient(
                    gradient: Gradient(colors: [Color.red, Color.blue]),
                    center: .center,
                    angle: .degrees(180))
            )
            .frame(width: 300, height: 200)
    }
}

#Preview {
    GradientsBootcamp()
}
