//
//  ColorsBootcamp.swift
//  SwiftUI_Bootcamp
//
//  Created by GuoMingJian on 2024/3/9.
//

import SwiftUI

struct ColorsBootcamp: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 25.0)
            .fill(
                //                Color.primary
                //                Color(.orange)
                Color("CustomColor")
            )
            .frame(width: 300, height: 200)
        //            .shadow(radius: 10)
            .shadow(color: .red.opacity(0.3), radius: 10, x: -5, y: -5)
    }
}

#Preview {
    ColorsBootcamp()
}
